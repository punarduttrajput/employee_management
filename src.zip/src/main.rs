#![feature(proc_macro_hygiene, decl_macro)]

#[macro_use] extern crate rocket;
use rocket::response::Redirect;
// use rocket::response::content::Json;
use mysql::prelude::*;
use mysql::*;
use rocket::Request;
use rocket_contrib::templates::Template;
// use std::io::Read;

// use rocket_contrib::uuid::Uuid;
// use rocket_contrib::serve::StaticFiles;
use rocket_contrib::templates::tera::{Context, Tera};
use serde::{Deserialize, Serialize};

#[derive(Debug, PartialEq, Eq)]
struct Employee {
    employee_id: i64,
    employee_fname: String,
    employee_lname: String,
    employee_mail: String,
    password: String,
    user_type: i64,
}
//defining form data
#[derive(FromForm, Serialize, Deserialize)]
struct MyFormData {
    username: String,
    password: String,

}

//home get route
#[get("/")]
fn index() -> Template {
    #[derive(Serialize)]
    struct Context {
        first_name: String,
        last_name: String
    }
    let context = Context {
        first_name: String::from("Ankit"),
        last_name: String::from("Rajput")
      };

    
      Template::render("home", context)
}

//user get route with parameters

#[get("/<username>/<password>")]
fn user(username:String, password:String) -> Template {
    #[derive(Serialize)]
    struct Context {
        first_name: String,
        password: String,
        user_type:String,
    }
    let context = Context {
        first_name:username,
        password:password,
        user_type:String::from("User")
      };
      Template::render("user", context)
}


//admin get route with parameters
#[get("/<username>/<password>")]
fn admin(username:String, password:String) -> Template {
    #[derive(Serialize)]
    struct Context {
        first_name: String,
        password: String,
        user_type:String
    }
    let context = Context {
        first_name:username,
        password:password,
        user_type:String::from("Admin")
      };
      Template::render("admin", context)
}


//get route for wrong parameter
#[get("/")]
fn wrong() -> Template{
    #[derive(Serialize)]
    struct Context {
        first_name: String
    }
    let context = Context {
        first_name: String::from("Wrong Password"),
      };
    Template::render("welcome", context) 
}


//post route for taking form input
#[post("/", data = "<form_data>")]
fn login(form_data: rocket::request::Form<MyFormData>) -> Redirect {
     let username = form_data.username.clone();
     let password = form_data.password.clone();

    let mut context = Context::new();
    context.insert("username", &form_data.username);

    let url = "mysql://root:7860$Ankit@localhost:3306/mcn";
    let pool = Pool::new(url).unwrap();
    //creating a connection
    let mut conn = pool.get_conn().unwrap();
    let uname:String = username.clone();
    let v:Vec<String> = signin(&mut conn, &username);
    let pass:String = v[0].clone();
    let fname:String = v[3].clone();
    let uid:String = v[4].clone();
    if password == pass{
        if uid == "1".to_string(){
            let url = format!("/admin/{}/{}",fname,password);
            Redirect::to(url)
        }
        else{
            let url = format!("/user/{}/{}",fname,password);
            Redirect::to(url)
        }
    }
    else{
        Redirect::to("/wrong")
    }
}


//route for 404 rsponse
#[catch(404)]
fn not_found(req: &Request) -> String {
    format!("Oh no! We couldn't find the requested path '{}'", req.uri())
}


//main function
fn main() {
    rocket::ignite()
  .mount("/login", routes![login])
  .register(catchers![not_found])
  .mount("/", routes![index])
  .mount("/user", routes![user])
  .mount("/admin", routes![admin])
  .mount("/wrong", routes![wrong])
  .attach(Template::fairing())
  .launch();


//   let url = "mysql://your_username:password@localhost:3306/db_name";
//   let pool = Pool::new(url).unwrap();
//   //creating a connection
//   let mut conn = pool.get_conn().unwrap();
}

fn signin(cn: &mut PooledConn, mail: &String) ->Vec<String> {
    let mut result:Vec<String> = Vec::new();
    let y=format!("select EmployeeID, EmployeeFirstName, EmployeeLastName, EmployeeEmail, password, UserTypeId from employee where EmployeeEmail= \"{}\"",mail);
    let res = cn
        .query_map(
            y,
            |(
                employee_id,
                employee_fname,
                employee_lname,
                employee_mail,
                password,
                user_type,
            )| Employee {
                employee_id: employee_id,
                employee_fname: employee_fname,
                employee_lname: employee_lname,
                employee_mail: employee_mail,
                password: password,
                user_type: user_type,
            },
        )
        .expect("Query failed.");
    let mut pass: String = String::new();
    let mut mail: String = String::new();
    let mut esid:String = String::new();
    let mut name: String = String::new();
    let mut utid: String  = String::new();
    for r in res {
        pass = r.password;
        mail = r.employee_mail;
        esid = r.employee_id.to_string();
        name = r.employee_fname;
        utid = r.user_type.to_string();
        result.push(pass);
        result.push(mail);
        result.push(esid);
        result.push(name);
        result.push(utid);
    }
    result
}
fn mark_attendance( cn:&mut PooledConn , id:i64)
{
cn.exec_drop(
   "insert into attendance (EntryDate, IsPresent, employeeId) values (now(), :ispresent, :empid)",
   params! {
       // "entrydate" => CURDATE(),
       "ispresent" => "true",
       "empid" => id
       
   },
).unwrap();
//println!("Last generated key: {}", conn.last_insert_id());
}

